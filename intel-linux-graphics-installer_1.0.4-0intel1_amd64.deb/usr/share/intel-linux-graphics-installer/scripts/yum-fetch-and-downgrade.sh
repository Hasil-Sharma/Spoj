#!/bin/bash

############################################################################
# Copyright © 2012-2013 Intel Corporation
#
# Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
#          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
############################################################################

cd $(mktemp -d ~/ilg.downgrade.XXXXXX)

ARCH=$(uname -m | sed -e 's/_/-/g');
DEVPACKLIST=;
PACKAGELIST="$@";

strip_package_name ()
{
    name=;
    name=$(echo -n $1 | sed -re 's@(\.[^.]+)$@@');
    name=$(rpm -q $name --qf %{NAME});
}

make_target_list ()
{
    targets=;
    targets=$(echo "$@" | sed -re 's/ /\n/g' | sort -u);
}


for pkg in $PACKAGELIST;
do
    for provision in $pkg $pkg"($ARCH)" $pkg\(noarch\);
    do
        for dep in $(rpm -q --whatrequires $provision | grep -v 'no package');
        do
            strip_package_name $dep;
            DEVPACKLIST=$DEVPACKLIST${DEVPACKLIST:+ }$name;
        done;
    done;
done;

make_target_list $DEVPACKLIST $PACKAGELIST;

if [ -n "$targets" ];
then
    yumdownloader $targets;
    shopt -s nullglob;
    yum -y downgrade *.$(uname -m).rpm *.noarch.rpm
else
    echo Nothing to downgrade 1>&2;
fi;
