#!/bin/sh

set -x

if [ -f $1 ]; then
    rm $1
fi
